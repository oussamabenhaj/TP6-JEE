package packJDBC;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        BookEm bookEm = new BookEmImpl();

        System.out.println("a. Affichage de tous les enregistrements de la table book :");
        List<Book> allBooks = bookEm.bookDisplayAll();
        for (Book book : allBooks) {
            System.out.println(book);
        }

        System.out.println("\nb. Ajout d'un nouveau book :");
        Book newBook = new Book("Nouveau Livre", "Nouvel Auteur", 2024);
        bookEm.bookAdd(newBook);

        System.out.println("\nc. Affichage du nouveau book ajouté :");
        List<Book> addedBook = bookEm.bookFindByKw("Nouveau Livre");
        for (Book book : addedBook) {
            System.out.println(book);
        }

        System.out.println("\nd. Modification du prix du book :");
        Book updatedBook = new Book("Nouveau Titre", "Nouvel Auteur", 2024);
        bookEm.updateBook(updatedBook);

        System.out.println("\ne. Suppression d'un book :");
        List<Book> toDelete = bookEm.bookFindByKw("Nouveau Titre");
        if (!toDelete.isEmpty()) {
            bookEm.deleteBook(toDelete.get(0).getId());
            System.out.println("Livre supprimé avec succès !");
        } else {
            System.out.println("Le livre à supprimer n'a pas été trouvé.");
        }
    }
}
